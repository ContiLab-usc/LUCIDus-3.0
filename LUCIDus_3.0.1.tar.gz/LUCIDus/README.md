
# LUCIDus Version 3

<!-- badges: start -->
<!-- badges: end -->

The goal of LUCIDus Version 3 is to ...

## Installation

You can install the development version of LUCIDusM from [GitHub](https://github.com/) with:

``` r
# install.packages("devtools")
devtools::install_github("ContiLab-usc/LUCIDusM",ref="main",auth_token = "xxx")
```
Note that this repo is now private, so only autherized users can download this package. Please go to [tokens](https://github.com/settings/tokens) to obtain your personal authorized token and input it into auth_token = "xxx" to download this package.

## Example

This is a basic example which shows you how to solve a common problem:

``` r
library(LUCIDus)
## basic example code
```

